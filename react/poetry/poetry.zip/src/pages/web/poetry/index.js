// 古诗组件

import React, { Component } from 'react'

class Poetry extends Component {
  render () {
    return (
      <div>我是古诗组件</div>
    )
  }
}

export default Poetry