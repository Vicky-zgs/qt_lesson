// 首页布局组件

import React, { Component } from 'react'
import './layout.less'

class WebLayout extends Component {
  render () {
    return (
      <div className="HomeWrapper">
        <div className="content-list">
          <div className="content-item">
            <span className="title">六月中遇火</span>
            <span className="author">陶渊明</span>
            <div className="content">
              <p>草庐寄穷巷，甘以辞华轩。</p>
              <p>果菜始复生，惊鸟尚未还。</p>
              <p>一宅无遗宇，肪舟荫门前。</p>
              <p>迢迢新秋夕，亭亭月将圆。</p>
              <p>果菜始复生，惊鸟尚未还。</p>
            </div>
            <div className="border"></div>
            <div className="content-tag">
            感叹
            </div>
          </div>

          <div className="content-item">
            <span className="title">六月中遇火</span>
            <span className="author">陶渊明</span>
            <div className="content">
              <p>草庐寄穷巷，甘以辞华轩。</p>
              <p>果菜始复生，惊鸟尚未还。</p>
              <p>一宅无遗宇，肪舟荫门前。</p>
              <p>迢迢新秋夕，亭亭月将圆。</p>
              <p>果菜始复生，惊鸟尚未还。</p>
            </div>
            <div className="border"></div>
            <div className="content-tag">
            感叹
            </div>
          </div>

          <div className="content-item">
            <span className="title">六月中遇火</span>
            <span className="author">陶渊明</span>
            <div className="content">
              <p>草庐寄穷巷，甘以辞华轩。</p>
              <p>果菜始复生，惊鸟尚未还。</p>
              <p>一宅无遗宇，肪舟荫门前。</p>
              <p>迢迢新秋夕，亭亭月将圆。</p>
              <p>果菜始复生，惊鸟尚未还。</p>
            </div>
            <div className="border"></div>
            <div className="content-tag">
            感叹
            </div>
          </div>

        </div>
        <div className="tag">
          <div className="tag-item">小学古诗</div>
          <div className="tag-item">初中古诗</div>
          <div className="tag-item">高中古诗</div>
          <div className="tag-item">唐诗三百</div>
          <div className="tag-item">宋词三百</div>
          <div className="tag-item">宋词精选</div>
        </div>
      </div>
    )
  }
}

export default WebLayout