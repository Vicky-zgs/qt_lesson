// 文章组件

import React, { Component } from 'react'

class Article extends Component {
  render () {
    return (
      <div>我是文章组件</div>
    )
  }
}

export default Article