// 诗人组件

import React, { Component } from 'react'

class Poet extends Component {
  render () {
    return (
      <div>我是诗人组件</div>
    )
  }
}

export default Poet