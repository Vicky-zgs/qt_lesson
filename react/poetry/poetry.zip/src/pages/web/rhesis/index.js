// 名句组件

import React, { Component } from 'react'

class Rhesis extends Component {
  render () {
    return (
      <div>我是名句组件</div>
    )
  }
}

export default Rhesis