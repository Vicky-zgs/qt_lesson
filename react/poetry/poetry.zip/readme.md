# 古诗词前端
- npm install antd --save
- npm i react-router-dom
- npm i less less-loader --save
- npm i react-particles-js
- npm install react-loadable

# pages
  admin中的页面与用户相关, web是网页
  - admin/login 登录页面
  - web/layout 主页面
  - web/list   主页面中的展示列表组件